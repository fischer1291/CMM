// ✅ Datei: app/_layout.tsx
import React, { useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import { AuthProvider, useAuth } from '../contexts/AuthContext';

function LayoutRouter() {
    const { userPhone } = useAuth();
    const [key, setKey] = useState(0);

    // ⏱ Neu rendern, wenn sich userPhone verändert (z. B. bei Login / Logout)
    useEffect(() => {
        setKey((prev) => prev + 1);
    }, [userPhone]);

    return (
        <Stack key={key} screenOptions={{ headerShown: false }}>
            {userPhone ? (
                <Stack.Screen name="(tabs)" />
            ) : (
                <Stack.Screen name="(auth)" />
            )}
        </Stack>
    );
}

export default function RootLayout() {
    return (
        <AuthProvider>
            <LayoutRouter />
        </AuthProvider>
    );
}